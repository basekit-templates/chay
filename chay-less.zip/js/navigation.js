
// Custom Toggle
$(document).on("click", ".navigation-toggle", function() {
    $( ".row__container" ).toggleClass( "navigation-open" );
});
